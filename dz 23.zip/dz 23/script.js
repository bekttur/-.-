let div = $("#div");
let btn = document.querySelector("#btn");

btn.addEventListener('click', () => {


    $.ajax({
        url: "https://randomuser.me/api/",
        method: "get",
        success: function (response) {
            div.append(`
                <div class = "user">
                Name: ${response.results[0].name.title} ${response.results[0].name.first} ${response.results[0].name.last}<br>
                Date of birth: ${response.results[0].dob.date}<br>
                Age: ${response.results[0].dob.age}<br>
                Address: ${response.results[0].location.street.number} ${response.results[0].location.street.name}<br>
                Location: ${response.results[0].location.city} ${response.results[0].location.state} ${response.results[0].location.country}<br>
                Phone: ${response.results[0].phone} and ${response.results[0].cell}<br>
                Email: ${response.results[0].email}<br>
                Registered: ${response.results[0].registered.date}<br><br>
                <img src = "${response.results[0].picture.large}" width = "100px">
                </div>
                <hr>
    `)
        },
        error: function (response) {
            console.log("error");
        }
    }

    )

})
